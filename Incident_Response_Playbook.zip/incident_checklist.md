# Quick Incident Response Checklist

## First 15 minutes (adapt to policy and severity)
- [ ] Record report time and incident ID.
- [ ] Ask what happened and what the user clicked, opened, entered, or approved.
- [ ] Preserve the original email, headers, screenshots, and relevant logs.
- [ ] Assign an incident lead and initial severity.
- [ ] Escalate immediately if active account abuse, data exposure, or broad impact is suspected.

## Contain
- [ ] Reset exposed credentials from a trusted device.
- [ ] Revoke sessions/tokens and review MFA/recovery methods.
- [ ] Block verified malicious indicators.
- [ ] Search for other recipients and affected accounts.
- [ ] Isolate affected endpoints using approved procedures.

## Recover and close
- [ ] Remove persistence and correct the root cause.
- [ ] Restore/reenable only after validation and approval.
- [ ] Monitor for recurrence.
- [ ] Record actions, timestamps, evidence location, and decisions.
- [ ] Notify stakeholders as required.
- [ ] Assign lessons-learned actions and owners.
