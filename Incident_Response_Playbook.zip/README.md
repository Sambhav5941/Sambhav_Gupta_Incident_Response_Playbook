# Cybersecurity Incident Response Playbook

**Project type:** Documentation / tabletop simulation  
**Scenario:** A staff member reports a suspicious email and a possible credential leak.  
**Purpose:** Provide a repeatable response process for a small organization.

> This is a fictional training scenario. Adapt the plan to your organization's policies and applicable laws. Do not access or collect real user credentials.

## 1. Objectives
- Identify and validate a suspected security incident.
- Limit damage while preserving evidence.
- Remove the cause and restore normal operations safely.
- Communicate clearly and document lessons learned.

## 2. Severity levels
| Level | Example | Target response |
|---|---|---|
| SEV-1 Critical | Confirmed widespread compromise, ransomware, major service outage | Immediate escalation |
| SEV-2 High | Confirmed account compromise or sensitive data exposure | Urgent escalation |
| SEV-3 Medium | Suspicious email clicked, compromise not confirmed | Prompt investigation |
| SEV-4 Low | Suspicious email reported, no interaction or indicators of compromise | Triage and monitor |

Targets are internal planning goals, not guarantees. Follow organizational policy.

## 3. Roles
- **Reporter:** Shares the message, time received, and actions taken; does not forward it to others.
- **Incident lead:** Coordinates decisions, severity, timeline, and updates.
- **IT / Security:** Reviews email and identity logs, disables sessions, resets credentials, blocks indicators.
- **Communications / Management:** Approves internal or external notifications when required.
- **Legal / Privacy:** Advises on notification obligations if personal or regulated data may be involved.

In a small team, one person may cover several roles.

## 4. Response phases

### Phase A — Preparation
- Keep contact details for IT, security, management, and legal/privacy up to date.
- Enable MFA, email filtering, endpoint protection, backups, and centralized logging where available.
- Define an approved channel for reporting suspicious messages.
- Ensure responders know how to preserve evidence and who can authorize account suspension.

### Phase B — Identification and triage
1. Record the report time, reporter, recipient, sender address, subject, and message headers if available.
2. Ask whether the link was clicked, an attachment opened, credentials entered, or an MFA prompt approved.
3. Preserve the original email and relevant logs; do not click links or open attachments.
4. Check sender domain, URL reputation using approved tools, email authentication results, sign-in history, and endpoint alerts.
5. Assign a severity level and incident lead.
6. If compromise is plausible, move to containment while investigation continues.

### Phase C — Containment
- If credentials may be exposed, reset the affected password from a trusted device and revoke active sessions/tokens.
- Enforce or re-check MFA and review recovery methods.
- Temporarily disable or restrict the account if active abuse is suspected and authorized.
- Block confirmed malicious sender addresses, domains, URLs, and file hashes using approved controls.
- Search for and remove matching messages from other mailboxes where tools and authorization permit.
- Isolate a suspected compromised endpoint from the network using approved procedures; do not power it off unless policy or safety requires it.
- Record every action, its timestamp, and the person who performed it.

### Phase D — Eradication
- Remove malicious inbox rules, unauthorized OAuth grants, persistence mechanisms, and malicious files after evidence is preserved.
- Patch exploited software and correct the root cause.
- Scan affected endpoints with approved security tools.
- Confirm no unauthorized accounts, forwarding rules, or sessions remain.

### Phase E — Recovery
- Restore systems from known-good sources when needed.
- Re-enable accounts only after checks pass and an authorized owner approves.
- Monitor sign-in events, email rules, endpoint alerts, and outbound traffic for recurrence.
- Confirm with the system owner that essential services are functioning.
- Keep heightened monitoring for a defined period (for example, 72 hours), adjusted to risk and policy.

### Phase F — Lessons learned
- Hold a short review within five business days of closure.
- Identify root cause, what worked, delays, and gaps.
- Assign owners and due dates to improvements.
- Update this playbook and staff awareness material.

## 5. Incident checklist
- [ ] Incident ID assigned
- [ ] Date/time and reporter recorded
- [ ] Original email and headers preserved
- [ ] User actions documented
- [ ] Severity and incident lead assigned
- [ ] Identity and endpoint logs reviewed
- [ ] Credentials reset / sessions revoked if required
- [ ] Malicious indicators blocked
- [ ] Scope and affected accounts/devices identified
- [ ] Evidence stored with restricted access
- [ ] Recovery approved and completed
- [ ] Monitoring completed
- [ ] Stakeholders notified as required
- [ ] Lessons-learned review scheduled/completed
- [ ] Corrective actions assigned

## 6. Evidence log template
| Timestamp (with timezone) | Evidence / action | Source / system | Collected by | Storage location | Notes |
|---|---|---|---|---|---|
| YYYY-MM-DD HH:MM | Example: suspicious email preserved | Mail platform | Analyst | Restricted case folder | Redact personal data in reports |

Maintain chain-of-custody details when required. Limit access to evidence and avoid sharing secrets in chat or public repositories.

## 7. Communication templates

### Initial internal update
**Subject:** Security incident under investigation — [Incident ID]

We are investigating a reported suspicious email. Please do not click related links, open attachments, or forward the message. If you interacted with it or entered credentials, contact the IT/security team through the approved channel. Further updates will be shared when verified.

### Incident closure update
**Subject:** Incident [Incident ID] — closure summary

The investigation has been completed and recovery checks have been performed. The incident summary, actions taken, and follow-up tasks are recorded in the case log. Please continue reporting suspicious messages through the approved channel.

## 8. Tabletop exercise
**Scenario:** An employee reports a fake cloud-storage notification and says they entered their password.

**Expected actions:**
1. Create an incident record and assign a lead.
2. Establish what was clicked and whether credentials or MFA approvals were provided.
3. Reset credentials from a trusted device and revoke sessions; check MFA and recovery settings.
4. Review sign-in logs, mailbox rules, OAuth grants, and messages sent from the account.
5. Search for other recipients and block confirmed indicators.
6. Preserve evidence, communicate with stakeholders, and document decisions.
7. Verify recovery and schedule a lessons-learned review.

**Discussion questions:**
- What evidence is essential before deleting the message?
- Who can authorize account suspension?
- What would increase severity to SEV-1 or SEV-2?
- Which privacy or legal obligations might apply?
- How will the team verify that the attacker no longer has access?

## 9. Workflow
`Report → Triage → Assign severity → Contain → Eradicate → Recover → Monitor → Lessons learned`

At any stage, if new evidence shows wider impact, reassess severity and escalate.

## 10. Limitations
This playbook is a training baseline, not legal advice or a substitute for an organization's approved incident response policy. Timelines, reporting duties, evidence handling, and external communications must follow applicable laws and organizational procedures.

## Suggested repository description
`A practical incident response playbook with phishing scenario, response phases, checklist, evidence log, and tabletop exercise.`
